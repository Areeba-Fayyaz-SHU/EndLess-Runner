public class HealthBar {
    private float health;

    public HealthBar() {
        this.health = Constants.HEALTH_MAX;
    }

    public void addHealth() {
        if (this.health < Constants.HEALTH_MAX) {
            this.health += 1;
        }
    }

    public void removeHealth() {
        if (this.health > 0) {
            this.health -= 1;
        }
        checkHealth(); // Call checkHealth whenever health is reduced
    }

    public float getHealth() {
        return this.health;
    }

    public void setHealth(int health) {
        this.health = health;
        checkHealth(); // Call checkHealth whenever health is set
    }

    public int getX() {
        return Constants.HEALTHBAR_X + Constants.HEALTHBAR_WIDTH - (int) (this.health / Constants.HEALTH_MAX * Constants.HEALTHBAR_WIDTH);
    }

    public float getHealthPercentage() {
        return this.health / Constants.HEALTH_MAX;
    }

    // New method to check health and exit the game when it reaches zero
    private void checkHealth() {
        if (this.health <= 0) {
            System.out.println("Game Over! Exiting...");
            // Exits the Program
            System.exit(0); 
        }
    }
}
